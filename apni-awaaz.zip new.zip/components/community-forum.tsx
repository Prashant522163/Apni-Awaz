"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ForumSidebar } from "@/components/community/forum-sidebar"
import { CommunityIssueCard } from "@/components/community/community-issue-card"
import { DiscussionThread } from "@/components/community/discussion-thread"
import { Search, Plus, TrendingUp, Grid, List } from "lucide-react"

// Mock data for community issues
const mockCommunityIssues = [
  {
    id: "IZ2025001234",
    title: "Large pothole on MG Road causing traffic issues",
    category: { name: "Roads & Transport", color: "text-red-500", icon: "Car" },
    priority: { level: "high", label: "High Priority", color: "text-orange-500" },
    status: { current: "in_progress", label: "In Progress", color: "text-yellow-500", progress: 65 },
    location: { address: "MG Road, Connaught Place, New Delhi", distance: "0.5 km" },
    submittedDate: "2025-01-15T10:30:00Z",
    reporter: { name: "Priya Sharma", avatar: "/placeholder.svg?key=user1", verified: true },
    department: "Public Works Department",
    images: ["/pothole-on-road-before-repair.jpg"],
    upvotes: 23,
    downvotes: 2,
    meTooCount: 15,
    comments: 8,
    verified: true,
    description:
      "There is a large pothole on MG Road near the metro station that has been causing significant traffic delays and vehicle damage.",
    daysAgo: 5,
  },
  {
    id: "IZ2025001567",
    title: "Broken street light making area unsafe at night",
    category: { name: "Electricity & Street Lights", color: "text-yellow-500", icon: "Lightbulb" },
    priority: { level: "medium", label: "Medium Priority", color: "text-yellow-500" },
    status: { current: "resolved", label: "Resolved", color: "text-green-500", progress: 100 },
    location: { address: "Sector 15, Gurgaon", distance: "1.2 km" },
    submittedDate: "2025-01-10T18:45:00Z",
    reporter: { name: "Rajesh Kumar", avatar: "/placeholder.svg?key=user2", verified: false },
    department: "Electricity Board",
    images: ["/dark-street-with-broken-streetlight.jpg"],
    upvotes: 15,
    downvotes: 0,
    meTooCount: 8,
    comments: 5,
    verified: true,
    description: "The street light has been broken for over a week, making the area unsafe for pedestrians at night.",
    daysAgo: 10,
  },
  {
    id: "IZ2025001890",
    title: "Irregular garbage collection causing hygiene issues",
    category: { name: "Sanitation & Cleanliness", color: "text-green-500", icon: "Trash2" },
    priority: { level: "low", label: "Low Priority", color: "text-green-500" },
    status: { current: "acknowledged", label: "Acknowledged", color: "text-blue-500", progress: 25 },
    location: { address: "Lajpat Nagar, Delhi", distance: "2.1 km" },
    submittedDate: "2025-01-08T12:20:00Z",
    reporter: { name: "Anita Verma", avatar: "/placeholder.svg?key=user3", verified: true },
    department: "Municipal Corporation",
    images: ["/overflowing-garbage-bins-on-street.jpg"],
    upvotes: 31,
    downvotes: 3,
    meTooCount: 22,
    comments: 12,
    verified: false,
    description:
      "Garbage collection has been irregular in our area for the past month, leading to overflowing bins and hygiene issues.",
    daysAgo: 17,
  },
]

export function CommunityForum() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("hot")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedIssue, setSelectedIssue] = useState<(typeof mockCommunityIssues)[0] | null>(null)

  const filteredIssues = mockCommunityIssues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.address.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory =
      selectedCategory === "all" || issue.category.name.toLowerCase().includes(selectedCategory.toLowerCase())
    return matchesSearch && matchesCategory
  })

  const sortedIssues = [...filteredIssues].sort((a, b) => {
    switch (sortBy) {
      case "hot":
        return b.upvotes + b.comments - (a.upvotes + a.comments)
      case "recent":
        return new Date(b.submittedDate).getTime() - new Date(a.submittedDate).getTime()
      case "upvoted":
        return b.upvotes - a.upvotes
      default:
        return 0
    }
  })

  if (selectedIssue) {
    return <DiscussionThread issue={selectedIssue} onBack={() => setSelectedIssue(null)} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/10 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Community Forum</h1>
          <p className="text-lg text-muted-foreground max-w-3xl">
            Connect with your neighbors, discuss civic issues, and work together to improve your community through
            collective action.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-80 flex-shrink-0">
            <ForumSidebar selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Header Actions */}
            <Card className="mb-6 border-border/50">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between mb-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      placeholder="Search discussions..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button className="bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    New Discussion
                  </Button>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Sort by:</span>
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="bg-background border border-border rounded px-2 py-1 text-sm"
                      >
                        <option value="hot">Hot</option>
                        <option value="recent">Recent</option>
                        <option value="upvoted">Most Upvoted</option>
                      </select>
                    </div>
                    <div className="flex border border-border rounded-lg">
                      <Button
                        variant={viewMode === "grid" ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setViewMode("grid")}
                        className="rounded-r-none"
                      >
                        <Grid className="w-4 h-4" />
                      </Button>
                      <Button
                        variant={viewMode === "list" ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setViewMode("list")}
                        className="rounded-l-none"
                      >
                        <List className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <TrendingUp className="w-4 h-4" />
                    <span>{sortedIssues.length} active discussions</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Issues Feed */}
            {sortedIssues.length === 0 ? (
              <Card className="border-border/50">
                <CardContent className="p-12 text-center">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">No discussions found</h3>
                  <p className="text-muted-foreground mb-6">
                    Try adjusting your search terms or browse different categories
                  </p>
                  <Button>Start a New Discussion</Button>
                </CardContent>
              </Card>
            ) : (
              <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 gap-6" : "space-y-4"}>
                {sortedIssues.map((issue) => (
                  <CommunityIssueCard
                    key={issue.id}
                    issue={issue}
                    viewMode={viewMode}
                    onClick={() => setSelectedIssue(issue)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
