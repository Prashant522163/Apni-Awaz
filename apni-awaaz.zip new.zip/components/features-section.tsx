import { Card, CardContent } from "@/components/ui/card"
import { Camera, MapPin, Bell, Users, CheckCircle, Clock } from "lucide-react"

export function FeaturesSection() {
  const features = [
    {
      icon: Camera,
      title: "Snap, Tag, Send",
      description:
        "Report issues in under 30 seconds with our intuitive photo-first interface. Just snap a photo, add location, and submit.",
      color: "text-primary",
    },
    {
      icon: Bell,
      title: "Stay Updated",
      description:
        "Get real-time notifications at every step of the resolution process. Never wonder about the status of your reports again.",
      color: "text-accent",
    },
    {
      icon: Users,
      title: "Community Power",
      description:
        "Community validation ensures accuracy and builds trust. Citizens can verify issues and support each other's reports.",
      color: "text-secondary",
    },
    {
      icon: MapPin,
      title: "Precise Location",
      description:
        "Advanced GPS integration and interactive maps ensure your issues are reported to the exact right location and department.",
      color: "text-primary",
    },
    {
      icon: CheckCircle,
      title: "Transparent Process",
      description:
        "Track every step from submission to resolution with complete transparency. See exactly what's happening and when.",
      color: "text-secondary",
    },
    {
      icon: Clock,
      title: "Fast Response",
      description:
        "Average response time of 2 hours for acknowledgment and 3-5 days for resolution. Government accountability at its best.",
      color: "text-accent",
    },
  ]

  return (
    <section className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Civic Engagement Made Simple</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
            Powerful features designed to make reporting and tracking civic issues as easy as posting on social media.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="border-border/50 hover:border-border transition-all duration-300 hover:shadow-lg group"
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <div
                    className={`w-12 h-12 rounded-lg bg-muted flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
                  >
                    <feature.icon className={`w-6 h-6 ${feature.color}`} />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
