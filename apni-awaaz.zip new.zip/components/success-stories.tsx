"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star, MapPin, Calendar } from "lucide-react"
import { useState } from "react"

export function SuccessStories() {
  const [currentStory, setCurrentStory] = useState(0)

  const stories = [
    {
      id: "IZ2025001234",
      title: "Pothole Fixed on MG Road",
      location: "Connaught Place, New Delhi",
      beforeImage: "/pothole-on-road-before-repair.jpg",
      afterImage: "/smooth-road-after-pothole-repair.jpg",
      reportedDate: "Jan 15, 2025",
      resolvedDate: "Jan 18, 2025",
      reporter: "Priya Sharma",
      rating: 5,
      testimonial:
        "Amazing response time! The pothole that was causing traffic jams for months was fixed in just 3 days after I reported it through Apni Awaaz.",
      department: "Public Works Department",
    },
    {
      id: "IZ2025001567",
      title: "Street Light Restored",
      location: "Sector 15, Gurgaon",
      beforeImage: "/dark-street-with-broken-streetlight.jpg",
      afterImage: "/well-lit-street-with-working-streetlight.jpg",
      reportedDate: "Jan 10, 2025",
      resolvedDate: "Jan 12, 2025",
      reporter: "Rajesh Kumar",
      rating: 5,
      testimonial:
        "The broken street light was making our area unsafe at night. Thanks to this platform, it was fixed within 2 days and our neighborhood feels secure again.",
      department: "Electricity Board",
    },
    {
      id: "IZ2025001890",
      title: "Garbage Collection Improved",
      location: "Lajpat Nagar, Delhi",
      beforeImage: "/overflowing-garbage-bins-on-street.jpg",
      afterImage: "/clean-street-with-proper-garbage-collection.jpg",
      reportedDate: "Jan 8, 2025",
      resolvedDate: "Jan 11, 2025",
      reporter: "Anita Verma",
      rating: 4,
      testimonial:
        "The garbage collection schedule was irregular in our area. After reporting, the municipal corporation improved the frequency and our streets are much cleaner now.",
      department: "Municipal Corporation",
    },
  ]

  const nextStory = () => {
    setCurrentStory((prev) => (prev + 1) % stories.length)
  }

  const prevStory = () => {
    setCurrentStory((prev) => (prev - 1 + stories.length) % stories.length)
  }

  const story = stories[currentStory]

  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Real Stories, Real Impact</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-balance">
            See how citizens like you are transforming their communities through civic engagement and government
            accountability.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <Card className="border-border/50 overflow-hidden">
            <CardContent className="p-0">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
                {/* Before/After Images */}
                <div className="relative">
                  <div className="grid grid-cols-2 h-full">
                    <div className="relative">
                      <img
                        src={story.beforeImage || "/placeholder.svg"}
                        alt="Before"
                        className="w-full h-64 lg:h-full object-cover"
                      />
                      <div className="absolute top-4 left-4 bg-destructive text-destructive-foreground px-3 py-1 rounded-full text-sm font-medium">
                        Before
                      </div>
                    </div>
                    <div className="relative">
                      <img
                        src={story.afterImage || "/placeholder.svg"}
                        alt="After"
                        className="w-full h-64 lg:h-full object-cover"
                      />
                      <div className="absolute top-4 right-4 bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-sm font-medium">
                        After
                      </div>
                    </div>
                  </div>
                </div>

                {/* Story Details */}
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <div className="mb-6">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                      <span className="font-mono text-primary">#{story.id}</span>
                      <span>•</span>
                      <span>{story.department}</span>
                    </div>
                    <h3 className="text-2xl font-bold text-foreground mb-2">{story.title}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {story.location}
                      </div>
                    </div>
                  </div>

                  <blockquote className="text-lg text-foreground mb-6 italic leading-relaxed">
                    "{story.testimonial}"
                  </blockquote>

                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <div className="font-semibold text-foreground">{story.reporter}</div>
                      <div className="flex items-center gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < story.rating ? "text-accent fill-current" : "text-muted-foreground"}`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="text-right text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        Reported: {story.reportedDate}
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <Calendar className="w-4 h-4" />
                        Resolved: {story.resolvedDate}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={prevStory}>
                        <ChevronLeft className="w-4 h-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={nextStory}>
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {currentStory + 1} of {stories.length}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
