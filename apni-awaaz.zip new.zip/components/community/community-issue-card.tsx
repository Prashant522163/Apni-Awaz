"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MapPin, MessageSquare, ThumbsUp, Users, CheckCircle, Share2, MoreHorizontal } from "lucide-react"

interface CommunityIssue {
  id: string
  title: string
  category: { name: string; color: string; icon: string }
  priority: { level: string; label: string; color: string }
  status: { current: string; label: string; color: string; progress: number }
  location: { address: string; distance: string }
  submittedDate: string
  reporter: { name: string; avatar: string; verified: boolean }
  department: string
  images: string[]
  upvotes: number
  downvotes: number
  meTooCount: number
  comments: number
  verified: boolean
  description: string
  daysAgo: number
}

interface CommunityIssueCardProps {
  issue: CommunityIssue
  viewMode: "grid" | "list"
  onClick: () => void
}

export function CommunityIssueCard({ issue, viewMode, onClick }: CommunityIssueCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      month: "short",
      day: "numeric",
    })
  }

  if (viewMode === "list") {
    return (
      <Card className="border-border/50 hover:shadow-md transition-all duration-200 cursor-pointer" onClick={onClick}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            {/* Reporter Avatar */}
            <div className="relative flex-shrink-0">
              <img
                src={issue.reporter.avatar || "/placeholder.svg"}
                alt={issue.reporter.name}
                className="w-10 h-10 rounded-full"
              />
              {issue.reporter.verified && (
                <CheckCircle className="w-4 h-4 text-primary absolute -bottom-1 -right-1 bg-background rounded-full" />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium text-foreground">{issue.reporter.name}</span>
                  <span className="text-xs text-muted-foreground">•</span>
                  <span className="text-xs text-muted-foreground">{issue.daysAgo} days ago</span>
                  <Badge variant="outline" className="text-xs ml-2">
                    #{issue.id}
                  </Badge>
                </div>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>

              <h3 className="font-semibold text-foreground text-lg mb-2 line-clamp-1">{issue.title}</h3>

              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{issue.description}</p>

              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span className="truncate max-w-48">{issue.location.address}</span>
                  <span className="text-xs">({issue.location.distance})</span>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {issue.category.name}
                </Badge>
                {issue.verified && (
                  <div className="flex items-center gap-1 text-green-600">
                    <CheckCircle className="w-3 h-3" />
                    <span className="text-xs">Verified</span>
                  </div>
                )}
              </div>

              {/* Status Progress */}
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-medium ${issue.status.color}`}>{issue.status.label}</span>
                  <span className="text-xs text-muted-foreground">{issue.department}</span>
                </div>
                <Progress value={issue.status.progress} className="h-2" />
              </div>

              {/* Engagement */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="w-4 h-4" />
                    <span>{issue.upvotes}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>{issue.meTooCount}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    <span>{issue.comments}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    View Discussion
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card
      className="border-border/50 hover:shadow-lg transition-all duration-300 cursor-pointer group"
      onClick={onClick}
    >
      <CardContent className="p-0">
        {/* Image */}
        <div className="relative h-48 bg-muted overflow-hidden">
          {issue.images[0] ? (
            <img
              src={issue.images[0] || "/placeholder.svg"}
              alt="Issue"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <MapPin className="w-12 h-12 text-muted-foreground" />
            </div>
          )}

          {/* Overlays */}
          <div className="absolute top-3 left-3 flex gap-2">
            <Badge variant="secondary" className="text-xs font-medium">
              #{issue.id}
            </Badge>
            {issue.verified && (
              <Badge className="text-xs bg-green-600 hover:bg-green-700">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            )}
          </div>
          <div className="absolute top-3 right-3">
            <div className={`w-3 h-3 rounded-full ${issue.priority.color.replace("text-", "bg-")}`} />
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Reporter Info */}
          <div className="flex items-center gap-3 mb-4">
            <div className="relative">
              <img
                src={issue.reporter.avatar || "/placeholder.svg"}
                alt={issue.reporter.name}
                className="w-8 h-8 rounded-full"
              />
              {issue.reporter.verified && (
                <CheckCircle className="w-3 h-3 text-primary absolute -bottom-0.5 -right-0.5 bg-background rounded-full" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-foreground">{issue.reporter.name}</span>
                <span className="text-xs text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground">{issue.daysAgo} days ago</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" />
                <span>{issue.location.distance} away</span>
              </div>
            </div>
            <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-foreground text-lg mb-3 line-clamp-2 leading-tight">{issue.title}</h3>

          {/* Category and Location */}
          <div className="flex items-center gap-2 mb-3">
            <Badge variant="outline" className="text-xs">
              {issue.category.name}
            </Badge>
            <span className="text-xs text-muted-foreground truncate">{issue.location.address}</span>
          </div>

          {/* Status Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className={`text-sm font-medium ${issue.status.color}`}>{issue.status.label}</span>
              <span className="text-xs text-muted-foreground">{issue.status.progress}%</span>
            </div>
            <Progress value={issue.status.progress} className="h-2" />
          </div>

          {/* Engagement */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <ThumbsUp className="w-4 h-4" />
                <span>{issue.upvotes}</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>{issue.meTooCount}</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageSquare className="w-4 h-4" />
                <span>{issue.comments}</span>
              </div>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
