"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, TrendingUp, CheckCircle, AlertCircle, Users, Award, Star } from "lucide-react"

interface ForumSidebarProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

export function ForumSidebar({ selectedCategory, onCategoryChange }: ForumSidebarProps) {
  const categories = [
    { id: "all", name: "All Issues", count: 156, icon: Users },
    { id: "hot", name: "Hot Topics", count: 23, icon: TrendingUp },
    { id: "recent", name: "Recently Resolved", count: 45, icon: CheckCircle },
    { id: "verification", name: "Need Verification", count: 12, icon: AlertCircle },
    { id: "roads", name: "Roads & Transport", count: 34, icon: "🚗" },
    { id: "sanitation", name: "Sanitation", count: 28, icon: "🗑️" },
    { id: "water", name: "Water & Drainage", count: 19, icon: "💧" },
    { id: "electricity", name: "Electricity", count: 22, icon: "💡" },
    { id: "safety", name: "Public Safety", count: 15, icon: "🛡️" },
    { id: "parks", name: "Parks & Spaces", count: 18, icon: "🌳" },
  ]

  const locationFilters = [
    { name: "My Area", description: "Within 1 km", active: true },
    { name: "Nearby", description: "Within 5 km", active: false },
    { name: "City-wide", description: "All locations", active: false },
  ]

  const timeFilters = [
    { name: "Today", active: false },
    { name: "This Week", active: true },
    { name: "This Month", active: false },
    { name: "All Time", active: false },
  ]

  const topContributors = [
    { name: "Priya Sharma", points: 1250, badge: "Community Leader", avatar: "/placeholder.svg?key=user1" },
    { name: "Rajesh Kumar", points: 980, badge: "Active Reporter", avatar: "/placeholder.svg?key=user2" },
    { name: "Anita Verma", points: 750, badge: "Helpful Citizen", avatar: "/placeholder.svg?key=user3" },
  ]

  return (
    <div className="space-y-6">
      {/* Categories */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Categories</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="space-y-1">
            {categories.map((category) => {
              const Icon = typeof category.icon === "string" ? null : category.icon
              return (
                <button
                  key={category.id}
                  onClick={() => onCategoryChange(category.id)}
                  className={`w-full flex items-center justify-between p-3 text-left hover:bg-muted/50 transition-colors ${
                    selectedCategory === category.id ? "bg-muted border-r-2 border-primary" : ""
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {Icon ? (
                      <Icon className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <span className="text-sm">{category.icon}</span>
                    )}
                    <span className="text-sm font-medium text-foreground">{category.name}</span>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {category.count}
                  </Badge>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Location Filter */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Location
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {locationFilters.map((filter, index) => (
            <div key={index} className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-foreground">{filter.name}</div>
                <div className="text-xs text-muted-foreground">{filter.description}</div>
              </div>
              <div className={`w-3 h-3 rounded-full ${filter.active ? "bg-primary" : "bg-muted"}`} />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Time Filters */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Time Period
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {timeFilters.map((filter, index) => (
            <button
              key={index}
              className={`w-full text-left p-2 rounded-lg text-sm transition-colors ${
                filter.active ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-muted/50"
              }`}
            >
              {filter.name}
            </button>
          ))}
        </CardContent>
      </Card>

      {/* User Stats */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Your Contributions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">12</div>
              <div className="text-xs text-muted-foreground">Issues Reported</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-secondary">850</div>
              <div className="text-xs text-muted-foreground">Points Earned</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-accent" />
            <span className="text-sm text-foreground">Active Contributor</span>
          </div>
        </CardContent>
      </Card>

      {/* Top Contributors */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-lg">Top Contributors</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {topContributors.map((contributor, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="relative">
                <img
                  src={contributor.avatar || "/placeholder.svg"}
                  alt={contributor.name}
                  className="w-8 h-8 rounded-full"
                />
                {index === 0 && <Star className="w-3 h-3 text-yellow-500 absolute -top-1 -right-1 fill-current" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground truncate">{contributor.name}</div>
                <div className="text-xs text-muted-foreground">
                  {contributor.points} points • {contributor.badge}
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
