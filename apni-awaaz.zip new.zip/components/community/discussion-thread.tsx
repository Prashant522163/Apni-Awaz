"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import {
  ArrowLeft,
  MapPin,
  Calendar,
  ThumbsUp,
  Users,
  MessageSquare,
  Share2,
  Flag,
  Pin,
  CheckCircle,
  Reply,
  Heart,
  MoreHorizontal,
  Camera,
  Smile,
} from "lucide-react"

interface CommunityIssue {
  id: string
  title: string
  category: { name: string; color: string; icon: string }
  priority: { level: string; label: string; color: string }
  status: { current: string; label: string; color: string; progress: number }
  location: { address: string; distance: string }
  submittedDate: string
  reporter: { name: string; avatar: string; verified: boolean }
  department: string
  images: string[]
  upvotes: number
  downvotes: number
  meTooCount: number
  comments: number
  verified: boolean
  description: string
  daysAgo: number
}

interface DiscussionThreadProps {
  issue: CommunityIssue
  onBack: () => void
}

export function DiscussionThread({ issue, onBack }: DiscussionThreadProps) {
  const [newComment, setNewComment] = useState("")
  const [hasUpvoted, setHasUpvoted] = useState(false)
  const [hasMeToo, setHasMeToo] = useState(false)
  const [sortBy, setSortBy] = useState("newest")

  const mockComments = [
    {
      id: "1",
      author: { name: "Amit Singh", avatar: "/placeholder.svg?key=user4", verified: true, badge: "Local Resident" },
      content:
        "I've been facing the same issue for weeks! This pothole has damaged my car's tire twice. Really appreciate someone finally reporting this.",
      timestamp: "2025-01-16T14:30:00Z",
      likes: 12,
      replies: 2,
      isOfficial: false,
      images: [],
    },
    {
      id: "2",
      author: { name: "PWD Delhi", avatar: "/placeholder.svg?key=dept1", verified: true, badge: "Official Response" },
      content:
        "Thank you for reporting this issue. Our field team has been dispatched for assessment. We expect to begin repair work within 48 hours. Work order #PWD2025-0156 has been generated.",
      timestamp: "2025-01-16T16:45:00Z",
      likes: 28,
      replies: 5,
      isOfficial: true,
      images: [],
      pinned: true,
    },
    {
      id: "3",
      author: { name: "Neha Gupta", avatar: "/placeholder.svg?key=user5", verified: false, badge: "Community Member" },
      content:
        "Finally! I hope they fix it properly this time. The temporary patches they did last year didn't last even a month.",
      timestamp: "2025-01-17T09:15:00Z",
      likes: 8,
      replies: 1,
      isOfficial: false,
      images: [],
    },
  ]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

    if (diffDays === 1) return "1 day ago"
    if (diffDays < 7) return `${diffDays} days ago`
    return date.toLocaleDateString("en-IN", { month: "short", day: "numeric" })
  }

  const handleUpvote = () => {
    setHasUpvoted(!hasUpvoted)
  }

  const handleMeToo = () => {
    setHasMeToo(!hasMeToo)
  }

  const handleComment = () => {
    if (newComment.trim()) {
      // Here you would submit the comment
      setNewComment("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/10 to-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Button variant="ghost" onClick={onBack} className="mb-6 flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Community
        </Button>

        {/* Thread Header */}
        <Card className="mb-6 border-border/50">
          <CardContent className="p-8">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img
                    src={issue.reporter.avatar || "/placeholder.svg"}
                    alt={issue.reporter.name}
                    className="w-12 h-12 rounded-full"
                  />
                  {issue.reporter.verified && (
                    <CheckCircle className="w-4 h-4 text-primary absolute -bottom-1 -right-1 bg-background rounded-full" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground">{issue.reporter.name}</span>
                    {issue.reporter.verified && (
                      <Badge variant="secondary" className="text-xs">
                        Verified
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(issue.submittedDate)}</span>
                    <span>•</span>
                    <span>#{issue.id}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Share2 className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Flag className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-2 mb-4">
              <Badge variant="outline">{issue.category.name}</Badge>
              <div className={`w-3 h-3 rounded-full ${issue.priority.color.replace("text-", "bg-")}`} />
              <span className="text-sm text-muted-foreground">{issue.priority.label}</span>
              {issue.verified && (
                <Badge className="bg-green-600 hover:bg-green-700">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Community Verified
                </Badge>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-4">{issue.title}</h1>

            <p className="text-muted-foreground text-lg leading-relaxed mb-6">{issue.description}</p>

            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>{issue.location.address}</span>
                <span>({issue.location.distance})</span>
              </div>
              <span>•</span>
              <span>{issue.department}</span>
            </div>

            {/* Images */}
            {issue.images.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {issue.images.map((image, index) => (
                  <img
                    key={index}
                    src={image || "/placeholder.svg"}
                    alt={`Issue photo ${index + 1}`}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                ))}
              </div>
            )}

            {/* Status Progress */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className={`font-medium ${issue.status.color}`}>{issue.status.label}</span>
                <span className="text-sm text-muted-foreground">{issue.status.progress}% Complete</span>
              </div>
              <Progress value={issue.status.progress} className="h-3" />
            </div>

            {/* Engagement Actions */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant={hasUpvoted ? "default" : "outline"}
                  size="sm"
                  onClick={handleUpvote}
                  className="flex items-center gap-2"
                >
                  <ThumbsUp className="w-4 h-4" />
                  {hasUpvoted ? issue.upvotes + 1 : issue.upvotes}
                </Button>
                <Button
                  variant={hasMeToo ? "default" : "outline"}
                  size="sm"
                  onClick={handleMeToo}
                  className="flex items-center gap-2"
                >
                  <Users className="w-4 h-4" />
                  Me Too ({hasMeToo ? issue.meTooCount + 1 : issue.meTooCount})
                </Button>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <MessageSquare className="w-4 h-4" />
                  <span>{issue.comments} comments</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Comments Section */}
        <Card className="border-border/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Discussion ({mockComments.length})</CardTitle>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-background border border-border rounded px-2 py-1 text-sm"
                >
                  <option value="newest">Newest</option>
                  <option value="oldest">Oldest</option>
                  <option value="most-liked">Most Liked</option>
                </select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Comment Composer */}
            <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
              <Textarea
                placeholder="Share your thoughts, additional information, or ask questions..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="min-h-24 resize-none"
              />
              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm">
                    <Camera className="w-4 h-4 mr-2" />
                    Add Photo
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Smile className="w-4 h-4 mr-2" />
                    Emoji
                  </Button>
                </div>
                <Button onClick={handleComment} disabled={!newComment.trim()}>
                  Post Comment
                </Button>
              </div>
            </div>

            {/* Comments List */}
            <div className="space-y-6">
              {mockComments.map((comment) => (
                <div
                  key={comment.id}
                  className={`
                  p-6 rounded-lg border transition-all duration-200
                  ${comment.isOfficial ? "bg-primary/5 border-primary/20" : "bg-card border-border/50"}
                  ${comment.pinned ? "ring-2 ring-primary/20" : ""}
                `}
                >
                  <div className="flex items-start gap-4">
                    <div className="relative flex-shrink-0">
                      <img
                        src={comment.author.avatar || "/placeholder.svg"}
                        alt={comment.author.name}
                        className="w-10 h-10 rounded-full"
                      />
                      {comment.author.verified && (
                        <CheckCircle className="w-4 h-4 text-primary absolute -bottom-1 -right-1 bg-background rounded-full" />
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-semibold text-foreground">{comment.author.name}</span>
                        <Badge variant={comment.isOfficial ? "default" : "secondary"} className="text-xs">
                          {comment.author.badge}
                        </Badge>
                        {comment.pinned && (
                          <Badge variant="outline" className="text-xs">
                            <Pin className="w-3 h-3 mr-1" />
                            Pinned
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground">{formatDate(comment.timestamp)}</span>
                      </div>

                      <p className="text-foreground leading-relaxed mb-4">{comment.content}</p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                            <Heart className="w-4 h-4 mr-1" />
                            {comment.likes}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                            <Reply className="w-4 h-4 mr-1" />
                            Reply
                          </Button>
                          {comment.replies > 0 && (
                            <span className="text-sm text-muted-foreground">{comment.replies} replies</span>
                          )}
                        </div>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
