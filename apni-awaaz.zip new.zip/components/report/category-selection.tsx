"use client"

import { Card, CardContent } from "@/components/ui/card"
import type { IssueData } from "@/components/issue-reporting-wizard"
import { Car, Trash2, Droplets, Lightbulb, Shield, Trees, Construction, Wifi, Building } from "lucide-react"

interface CategorySelectionProps {
  issueData: IssueData
  setIssueData: (data: IssueData) => void
}

export function CategorySelection({ issueData, setIssueData }: CategorySelectionProps) {
  const categories = [
    {
      id: "roads",
      name: "Roads & Transport",
      icon: Car,
      examples: "Potholes, traffic signals, road damage",
      color: "text-red-500",
      bgColor: "bg-red-50 dark:bg-red-950/20",
      borderColor: "border-red-200 dark:border-red-800",
    },
    {
      id: "sanitation",
      name: "Sanitation & Cleanliness",
      icon: Trash2,
      examples: "Garbage collection, street cleaning",
      color: "text-green-500",
      bgColor: "bg-green-50 dark:bg-green-950/20",
      borderColor: "border-green-200 dark:border-green-800",
    },
    {
      id: "water",
      name: "Water & Drainage",
      icon: Droplets,
      examples: "Water leaks, drainage issues",
      color: "text-blue-500",
      bgColor: "bg-blue-50 dark:bg-blue-950/20",
      borderColor: "border-blue-200 dark:border-blue-800",
    },
    {
      id: "electricity",
      name: "Electricity & Street Lights",
      icon: Lightbulb,
      examples: "Power outages, broken streetlights",
      color: "text-yellow-500",
      bgColor: "bg-yellow-50 dark:bg-yellow-950/20",
      borderColor: "border-yellow-200 dark:border-yellow-800",
    },
    {
      id: "safety",
      name: "Public Safety & Security",
      icon: Shield,
      examples: "Security concerns, crime reports",
      color: "text-red-600",
      bgColor: "bg-red-50 dark:bg-red-950/20",
      borderColor: "border-red-200 dark:border-red-800",
    },
    {
      id: "parks",
      name: "Parks & Public Spaces",
      icon: Trees,
      examples: "Park maintenance, public facilities",
      color: "text-green-600",
      bgColor: "bg-green-50 dark:bg-green-950/20",
      borderColor: "border-green-200 dark:border-green-800",
    },
    {
      id: "construction",
      name: "Construction & Infrastructure",
      icon: Construction,
      examples: "Building violations, construction issues",
      color: "text-orange-500",
      bgColor: "bg-orange-50 dark:bg-orange-950/20",
      borderColor: "border-orange-200 dark:border-orange-800",
    },
    {
      id: "digital",
      name: "Digital Services",
      icon: Wifi,
      examples: "Website issues, digital service problems",
      color: "text-purple-500",
      bgColor: "bg-purple-50 dark:bg-purple-950/20",
      borderColor: "border-purple-200 dark:border-purple-800",
    },
    {
      id: "other",
      name: "Other Issues",
      icon: Building,
      examples: "Issues not covered in other categories",
      color: "text-gray-500",
      bgColor: "bg-gray-50 dark:bg-gray-950/20",
      borderColor: "border-gray-200 dark:border-gray-800",
    },
  ]

  const selectCategory = (category: (typeof categories)[0]) => {
    setIssueData({
      ...issueData,
      category: {
        id: category.id,
        name: category.name,
        icon: category.icon.name,
        color: category.color,
      },
    })
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold text-foreground mb-2">What type of issue would you like to report?</h3>
        <p className="text-muted-foreground">Select the category that best describes your issue</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map((category) => {
          const Icon = category.icon
          const isSelected = issueData.category?.id === category.id

          return (
            <Card
              key={category.id}
              className={`
                cursor-pointer transition-all duration-200 hover:shadow-md
                ${
                  isSelected
                    ? `${category.borderColor} border-2 ${category.bgColor}`
                    : "border-border hover:border-border/80"
                }
              `}
              onClick={() => selectCategory(category)}
            >
              <CardContent className="p-6 text-center">
                <div
                  className={`
                  w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center
                  ${isSelected ? category.bgColor : "bg-muted"}
                `}
                >
                  <Icon className={`w-8 h-8 ${isSelected ? category.color : "text-muted-foreground"}`} />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{category.name}</h4>
                <p className="text-sm text-muted-foreground">{category.examples}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
