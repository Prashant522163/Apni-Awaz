"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import type { IssueData } from "@/components/issue-reporting-wizard"
import { MapPin, Phone, Mail, Bell, Smartphone, Edit, Eye, EyeOff } from "lucide-react"

interface ReviewSubmitProps {
  issueData: IssueData
  setIssueData: (data: IssueData) => void
  onSubmit: () => void
}

export function ReviewSubmit({ issueData, setIssueData, onSubmit }: ReviewSubmitProps) {
  const [phoneNumber, setPhoneNumber] = useState(issueData.contact.phone)
  const [agreedToTerms, setAgreedToTerms] = useState(false)

  const updateContactPreference = (key: keyof typeof issueData.contact, value: boolean) => {
    setIssueData({
      ...issueData,
      contact: {
        ...issueData.contact,
        [key]: value,
      },
    })
  }

  const updatePrivacyOption = (key: keyof typeof issueData.privacy, value: boolean) => {
    setIssueData({
      ...issueData,
      privacy: {
        ...issueData.privacy,
        [key]: value,
      },
    })
  }

  const handlePhoneChange = (phone: string) => {
    setPhoneNumber(phone)
    setIssueData({
      ...issueData,
      contact: {
        ...issueData.contact,
        phone,
      },
    })
  }

  const handleSubmit = () => {
    if (agreedToTerms) {
      onSubmit()
    }
  }

  return (
    <div className="space-y-8">
      {/* Issue Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Issue Summary
            <Button variant="ghost" size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Media Preview */}
          {issueData.media.photos.length > 0 && (
            <div className="flex gap-2 overflow-x-auto">
              {issueData.media.photos.slice(0, 3).map((photo, index) => (
                <img
                  key={index}
                  src={URL.createObjectURL(photo) || "/placeholder.svg"}
                  alt={`Issue photo ${index + 1}`}
                  className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
                />
              ))}
              {issueData.media.photos.length > 3 && (
                <div className="w-20 h-20 bg-muted rounded-lg flex items-center justify-center flex-shrink-0">
                  <span className="text-sm text-muted-foreground">+{issueData.media.photos.length - 3}</span>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2">
                {issueData.category && (
                  <div className={`w-3 h-3 rounded-full ${issueData.category.color.replace("text-", "bg-")}`} />
                )}
                <span className="text-sm font-medium text-muted-foreground">{issueData.category?.name}</span>
              </div>
              <h3 className="font-semibold text-foreground text-lg mb-2">{issueData.title}</h3>
              <p className="text-muted-foreground text-sm line-clamp-3">{issueData.description}</p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">{issueData.location.address}</span>
              </div>
              {issueData.location.landmark && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="w-4 h-4" />
                  <span className="text-muted-foreground">Near {issueData.location.landmark}</span>
                </div>
              )}
              {issueData.priority && (
                <div className="flex items-center gap-2 text-sm">
                  <div className={`w-4 h-4 rounded-full ${issueData.priority.color.replace("text-", "bg-")}`} />
                  <span className="text-muted-foreground">{issueData.priority.label}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="sms"
                checked={issueData.contact.sms}
                onCheckedChange={(checked) => updateContactPreference("sms", checked as boolean)}
              />
              <label htmlFor="sms" className="flex items-center gap-2 text-sm font-medium">
                <Phone className="w-4 h-4" />
                SMS updates
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="email"
                checked={issueData.contact.email}
                onCheckedChange={(checked) => updateContactPreference("email", checked as boolean)}
              />
              <label htmlFor="email" className="flex items-center gap-2 text-sm font-medium">
                <Mail className="w-4 h-4" />
                Email notifications
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="push"
                checked={issueData.contact.push}
                onCheckedChange={(checked) => updateContactPreference("push", checked as boolean)}
              />
              <label htmlFor="push" className="flex items-center gap-2 text-sm font-medium">
                <Smartphone className="w-4 h-4" />
                Push notifications
              </label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="inApp"
                checked={issueData.contact.inApp}
                onCheckedChange={(checked) => updateContactPreference("inApp", checked as boolean)}
              />
              <label htmlFor="inApp" className="flex items-center gap-2 text-sm font-medium">
                <Bell className="w-4 h-4" />
                In-app notifications
              </label>
            </div>
          </div>

          {(issueData.contact.sms || issueData.contact.push) && (
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Phone Number (for SMS and verification)
              </label>
              <Input
                type="tel"
                placeholder="+91 9876543210"
                value={phoneNumber}
                onChange={(e) => handlePhoneChange(e.target.value)}
                className="max-w-xs"
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Privacy Options */}
      <Card>
        <CardHeader>
          <CardTitle>Privacy Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start space-x-2">
            <Checkbox
              id="public"
              checked={issueData.privacy.public}
              onCheckedChange={(checked) => updatePrivacyOption("public", checked as boolean)}
            />
            <div>
              <label htmlFor="public" className="flex items-center gap-2 text-sm font-medium">
                <Eye className="w-4 h-4" />
                Make this report public
              </label>
              <p className="text-xs text-muted-foreground mt-1">
                Allow community members to see and support this issue
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-2">
            <Checkbox
              id="allowMedia"
              checked={issueData.privacy.allowMedia}
              onCheckedChange={(checked) => updatePrivacyOption("allowMedia", checked as boolean)}
            />
            <div>
              <label htmlFor="allowMedia" className="text-sm font-medium">
                Allow media usage in success stories
              </label>
              <p className="text-xs text-muted-foreground mt-1">
                Let us use before/after photos to showcase successful resolutions
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-2">
            <Checkbox
              id="anonymous"
              checked={issueData.privacy.anonymous}
              onCheckedChange={(checked) => updatePrivacyOption("anonymous", checked as boolean)}
            />
            <div>
              <label htmlFor="anonymous" className="flex items-center gap-2 text-sm font-medium">
                <EyeOff className="w-4 h-4" />
                Submit anonymously
              </label>
              <p className="text-xs text-muted-foreground mt-1">
                Your name will not be visible to the public or government officials
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Processing Information */}
      <Card className="bg-muted/50">
        <CardContent className="p-6">
          <h4 className="font-medium text-foreground mb-3">What happens next?</h4>
          <div className="space-y-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-xs font-semibold text-primary">1</span>
              </div>
              <span>Within 2 hours: Issue review and department assignment</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-xs font-semibold text-primary">2</span>
              </div>
              <span>Within 24 hours: Field team notification</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center">
                <span className="text-xs font-semibold text-primary">3</span>
              </div>
              <span>
                Estimated resolution:{" "}
                {issueData.priority?.value === 4
                  ? "24-48 hours"
                  : issueData.priority?.value === 3
                    ? "3-5 business days"
                    : issueData.priority?.value === 2
                      ? "1-2 weeks"
                      : "2-4 weeks"}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Terms Agreement */}
      <div className="flex items-start space-x-2">
        <Checkbox
          id="terms"
          checked={agreedToTerms}
          onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
        />
        <div>
          <label htmlFor="terms" className="text-sm font-medium">
            I agree to the Terms of Service and Privacy Policy
          </label>
          <p className="text-xs text-muted-foreground mt-1">
            By submitting this report, you confirm that the information provided is accurate and you agree to our terms.
          </p>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex gap-4">
        <Button
          onClick={handleSubmit}
          disabled={!agreedToTerms}
          className="bg-primary hover:bg-primary/90 flex-1 sm:flex-none sm:px-8"
          size="lg"
        >
          Submit Report
        </Button>
        <Button variant="outline" size="lg">
          Save as Draft
        </Button>
      </div>
    </div>
  )
}
