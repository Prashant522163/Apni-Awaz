"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import type { IssueData } from "@/components/issue-reporting-wizard"
import { MapPin, Camera, Upload, X, Pause, RotateCw, Crop, Sun, Navigation } from "lucide-react"

interface LocationMediaProps {
  issueData: IssueData
  setIssueData: (data: IssueData) => void
}

export function LocationMedia({ issueData, setIssueData }: LocationMediaProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [recordingTime, setRecordingTime] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setIssueData({
            ...issueData,
            location: {
              ...issueData.location,
              coordinates: [position.coords.longitude, position.coords.latitude],
            },
          })
          // Here you would reverse geocode to get the address
          setIssueData({
            ...issueData,
            location: {
              ...issueData.location,
              coordinates: [position.coords.longitude, position.coords.latitude],
              address: "Current location detected - fetching address...",
            },
          })
        },
        (error) => {
          console.error("Error getting location:", error)
        },
      )
    }
  }

  const handleAddressChange = (address: string) => {
    setIssueData({
      ...issueData,
      location: {
        ...issueData.location,
        address,
      },
    })
  }

  const handleLandmarkChange = (landmark: string) => {
    setIssueData({
      ...issueData,
      location: {
        ...issueData.location,
        landmark,
      },
    })
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || [])
    if (files.length + issueData.media.photos.length <= 5) {
      setIssueData({
        ...issueData,
        media: {
          ...issueData.media,
          photos: [...issueData.media.photos, ...files],
        },
      })
    }
  }

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setIssueData({
        ...issueData,
        media: {
          ...issueData.media,
          video: file,
        },
      })
    }
  }

  const removePhoto = (index: number) => {
    const newPhotos = issueData.media.photos.filter((_, i) => i !== index)
    setIssueData({
      ...issueData,
      media: {
        ...issueData.media,
        photos: newPhotos,
      },
    })
  }

  const removeVideo = () => {
    setIssueData({
      ...issueData,
      media: {
        ...issueData.media,
        video: null,
      },
    })
  }

  const startRecording = () => {
    setIsRecording(true)
    setRecordingTime(0)
    // Here you would implement actual video recording
    const timer = setInterval(() => {
      setRecordingTime((prev) => {
        if (prev >= 30) {
          setIsRecording(false)
          clearInterval(timer)
          return 30
        }
        return prev + 1
      })
    }, 1000)
  }

  const stopRecording = () => {
    setIsRecording(false)
    // Here you would stop recording and save the video
  }

  return (
    <div className="space-y-8">
      {/* Location Section */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Location Information</h3>

        {/* Interactive Map Placeholder */}
        <Card className="mb-4">
          <CardContent className="p-0">
            <div className="h-64 bg-muted rounded-lg flex items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10" />
              <div className="text-center z-10">
                <MapPin className="w-12 h-12 text-primary mx-auto mb-2" />
                <p className="text-muted-foreground mb-4">Interactive Map</p>
                <div className="flex gap-2 justify-center">
                  <Button variant="outline" size="sm">
                    <Navigation className="w-4 h-4 mr-2" />
                    Satellite
                  </Button>
                  <Button variant="outline" size="sm">
                    Street View
                  </Button>
                </div>
              </div>
              {issueData.location.coordinates && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-6 h-6 bg-primary rounded-full animate-pulse" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Address Input */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Address *</label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter the address or location"
                value={issueData.location.address}
                onChange={(e) => handleAddressChange(e.target.value)}
                className="flex-1"
              />
              <Button variant="outline" onClick={getCurrentLocation} className="flex items-center gap-2 bg-transparent">
                <MapPin className="w-4 h-4" />
                Use Current
              </Button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Nearby Landmark (Optional)</label>
            <Input
              placeholder="Near [landmark/building name]"
              value={issueData.location.landmark}
              onChange={(e) => handleLandmarkChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Media Upload Section */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-4">Photos & Videos</h3>

        {/* Photo Upload */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-foreground mb-2">Photos (Required)</label>

          <Card
            className="border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <CardContent className="p-8 text-center">
              <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-foreground font-medium mb-2">Drag and drop photos here, or click to browse</p>
              <p className="text-sm text-muted-foreground mb-4">Max 5 photos • JPG, PNG • Up to 10MB each</p>
              <div className="flex gap-2 justify-center">
                <Button variant="outline" size="sm">
                  <Camera className="w-4 h-4 mr-2" />
                  Take Photo
                </Button>
                <Button variant="outline" size="sm">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose Files
                </Button>
              </div>
            </CardContent>
          </Card>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handlePhotoUpload}
            className="hidden"
          />

          {/* Photo Previews */}
          {issueData.media.photos.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mt-4">
              {issueData.media.photos.map((photo, index) => (
                <div key={index} className="relative group">
                  <img
                    src={URL.createObjectURL(photo) || "/placeholder.svg"}
                    alt={`Upload ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                    <Button variant="ghost" size="sm" className="text-white hover:text-white">
                      <Crop className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white hover:text-white">
                      <RotateCw className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-white hover:text-white">
                      <Sun className="w-4 h-4" />
                    </Button>
                  </div>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 w-6 h-6 p-0"
                    onClick={() => removePhoto(index)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Video Upload */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Video (Optional)</label>

          {!issueData.media.video ? (
            <Card className="border-2 border-dashed border-border">
              <CardContent className="p-6 text-center">
                <div className="flex gap-4 justify-center">
                  <Button
                    variant="outline"
                    onClick={isRecording ? stopRecording : startRecording}
                    className={isRecording ? "bg-red-50 border-red-200" : ""}
                  >
                    {isRecording ? (
                      <>
                        <Pause className="w-4 h-4 mr-2 text-red-500" />
                        Stop ({30 - recordingTime}s)
                      </>
                    ) : (
                      <>
                        <Camera className="w-4 h-4 mr-2" />
                        Record Video
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={() => videoInputRef.current?.click()}>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Video
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-3">Max 30 seconds • MP4 format • Up to 50MB</p>
              </CardContent>
            </Card>
          ) : (
            <div className="relative">
              <video
                src={URL.createObjectURL(issueData.media.video)}
                controls
                className="w-full h-48 object-cover rounded-lg"
              />
              <Button variant="destructive" size="sm" className="absolute top-2 right-2" onClick={removeVideo}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          <input ref={videoInputRef} type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />
        </div>

        {/* File Requirements */}
        <div className="bg-muted/50 p-4 rounded-lg mt-4">
          <h4 className="font-medium text-foreground mb-2">Media Guidelines</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Take clear photos showing the issue from multiple angles</li>
            <li>• Include context (street signs, landmarks) for better location identification</li>
            <li>• Ensure good lighting for better visibility</li>
            <li>• Videos should focus on the issue and avoid unnecessary movement</li>
            <li>• Do not include personal information or faces of individuals</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
