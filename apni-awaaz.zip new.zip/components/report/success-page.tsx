"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { IssueData } from "@/components/issue-reporting-wizard"
import { CheckCircle, Copy, QrCode, Share2, MessageSquare, ArrowRight, Clock, Users, MapPin } from "lucide-react"

interface SuccessPageProps {
  issueData: IssueData
}

export function SuccessPage({ issueData }: SuccessPageProps) {
  const [issueId] = useState(
    `IZ${new Date().getFullYear()}${String(Math.floor(Math.random() * 1000000)).padStart(6, "0")}`,
  )
  const [showConfetti, setShowConfetti] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 3000)
    return () => clearTimeout(timer)
  }, [])

  const copyIssueId = () => {
    navigator.clipboard.writeText(issueId)
  }

  const shareIssue = () => {
    if (navigator.share) {
      navigator.share({
        title: `Issue Reported: ${issueData.title}`,
        text: `I've reported a civic issue through Apni Awaaz. Issue ID: ${issueId}`,
        url: `${window.location.origin}/track/${issueId}`,
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-secondary/5 to-background py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Animation */}
        <div className="text-center mb-8">
          <div className="relative inline-block">
            <div
              className={`w-24 h-24 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6 ${showConfetti ? "animate-bounce" : ""}`}
            >
              <CheckCircle className="w-12 h-12 text-secondary-foreground" />
            </div>
            {showConfetti && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(20)].map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 bg-primary rounded-full animate-ping"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      animationDelay: `${Math.random() * 2}s`,
                      animationDuration: `${1 + Math.random()}s`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Issue Reported Successfully!</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Thank you for helping improve your community. Your report has been submitted and will be reviewed by the
            appropriate department.
          </p>
        </div>

        {/* Issue ID Card */}
        <Card className="mb-8 border-secondary/20 bg-gradient-to-r from-secondary/5 to-primary/5">
          <CardContent className="p-8 text-center">
            <h2 className="text-lg font-semibold text-foreground mb-4">Your Issue ID</h2>
            <div className="flex items-center justify-center gap-4 mb-6">
              <div className="text-3xl sm:text-4xl font-mono font-bold text-primary">{issueId}</div>
              <Button variant="outline" size="sm" onClick={copyIssueId}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>

            {/* QR Code Placeholder */}
            <div className="w-32 h-32 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
              <QrCode className="w-16 h-16 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">Scan QR code for quick access to issue status</p>
          </CardContent>
        </Card>

        {/* Timeline */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-foreground mb-6">What Happens Next</h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Clock className="w-4 h-4 text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">Within 2 hours</h4>
                  <p className="text-muted-foreground">Issue review and department assignment</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                  <Users className="w-4 h-4 text-accent-foreground" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">Within 24 hours</h4>
                  <p className="text-muted-foreground">Field team notification and initial assessment</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-4 h-4 text-secondary-foreground" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">
                    Estimated resolution:{" "}
                    {issueData.priority?.value === 4
                      ? "24-48 hours"
                      : issueData.priority?.value === 3
                        ? "3-5 business days"
                        : issueData.priority?.value === 2
                          ? "1-2 weeks"
                          : "2-4 weeks"}
                  </h4>
                  <p className="text-muted-foreground">Based on issue priority and category</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Issue Summary */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-foreground mb-4">Issue Summary</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  {issueData.category && (
                    <div className={`w-3 h-3 rounded-full ${issueData.category.color.replace("text-", "bg-")}`} />
                  )}
                  <span className="text-sm font-medium text-muted-foreground">{issueData.category?.name}</span>
                </div>
                <h4 className="font-semibold text-foreground text-lg mb-2">{issueData.title}</h4>
                <p className="text-muted-foreground text-sm">{issueData.description.substring(0, 150)}...</p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span className="text-muted-foreground">{issueData.location.address}</span>
                </div>
                {issueData.priority && (
                  <div className="flex items-center gap-2 text-sm">
                    <div className={`w-4 h-4 rounded-full ${issueData.priority.color.replace("text-", "bg-")}`} />
                    <span className="text-muted-foreground">{issueData.priority.label}</span>
                  </div>
                )}
                <div className="text-sm text-muted-foreground">
                  Submitted:{" "}
                  {new Date().toLocaleDateString("en-IN", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Button className="bg-primary hover:bg-primary/90" size="lg">
            <ArrowRight className="w-4 h-4 mr-2" />
            Track This Issue
          </Button>
          <Button variant="outline" size="lg" onClick={shareIssue}>
            <Share2 className="w-4 h-4 mr-2" />
            Share Issue
          </Button>
          <Button variant="outline" size="lg">
            <MessageSquare className="w-4 h-4 mr-2" />
            Join Discussion
          </Button>
        </div>

        {/* Additional Actions */}
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Want to report another issue or help your community?</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="outline">Report Another Issue</Button>
            <Button variant="outline">View Community Issues</Button>
            <Button variant="outline">Download Mobile App</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
