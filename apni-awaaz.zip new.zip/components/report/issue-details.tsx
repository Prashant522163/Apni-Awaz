"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import type { IssueData } from "@/components/issue-reporting-wizard"
import { Mic, MicOff } from "lucide-react"

interface IssueDetailsProps {
  issueData: IssueData
  setIssueData: (data: IssueData) => void
}

export function IssueDetails({ issueData, setIssueData }: IssueDetailsProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [titleCount, setTitleCount] = useState(issueData.title.length)
  const [descCount, setDescCount] = useState(issueData.description.length)

  const priorities = [
    {
      level: "low",
      value: 1,
      label: "Low Priority",
      description: "Can wait weeks",
      color: "text-green-500",
      bgColor: "bg-green-50 dark:bg-green-950/20",
      borderColor: "border-green-200 dark:border-green-800",
    },
    {
      level: "medium",
      value: 2,
      label: "Medium Priority",
      description: "Should be fixed within days",
      color: "text-yellow-500",
      bgColor: "bg-yellow-50 dark:bg-yellow-950/20",
      borderColor: "border-yellow-200 dark:border-yellow-800",
    },
    {
      level: "high",
      value: 3,
      label: "High Priority",
      description: "Needs attention within hours",
      color: "text-orange-500",
      bgColor: "bg-orange-50 dark:bg-orange-950/20",
      borderColor: "border-orange-200 dark:border-orange-800",
    },
    {
      level: "urgent",
      value: 4,
      label: "Urgent",
      description: "Immediate safety concern",
      color: "text-red-500",
      bgColor: "bg-red-50 dark:bg-red-950/20",
      borderColor: "border-red-200 dark:border-red-800",
    },
  ]

  const templates = [
    "There is a large pothole on [street name] that is causing damage to vehicles and creating traffic hazards.",
    "The streetlight at [location] has been broken for several days, making the area unsafe at night.",
    "Garbage has not been collected from [location] for over a week, causing hygiene issues.",
    "There is a water leak on [street name] that is wasting water and creating flooding.",
  ]

  const handleTitleChange = (value: string) => {
    if (value.length <= 100) {
      setTitleCount(value.length)
      setIssueData({
        ...issueData,
        title: value,
      })
    }
  }

  const handleDescriptionChange = (value: string) => {
    if (value.length <= 500) {
      setDescCount(value.length)
      setIssueData({
        ...issueData,
        description: value,
      })
    }
  }

  const selectPriority = (priority: (typeof priorities)[0]) => {
    setIssueData({
      ...issueData,
      priority: {
        level: priority.level,
        value: priority.value,
        label: priority.label,
        color: priority.color,
      },
    })
  }

  const useTemplate = (template: string) => {
    handleDescriptionChange(template)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    // Here you would implement actual voice-to-text functionality
  }

  return (
    <div className="space-y-8">
      {/* Issue Title */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">Issue Title *</label>
        <Input
          placeholder="Brief description of the problem"
          value={issueData.title}
          onChange={(e) => handleTitleChange(e.target.value)}
          className="text-lg"
        />
        <div className="flex justify-between items-center mt-2">
          <div className="text-sm text-muted-foreground">{titleCount}/100 characters</div>
          {issueData.category && (
            <div className="text-sm text-muted-foreground">
              Auto-suggestions available for {issueData.category.name}
            </div>
          )}
        </div>
      </div>

      {/* Detailed Description */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-sm font-medium text-foreground">Detailed Description *</label>
          <Button
            variant="outline"
            size="sm"
            onClick={toggleRecording}
            className={isRecording ? "bg-red-50 border-red-200" : ""}
          >
            {isRecording ? (
              <>
                <MicOff className="w-4 h-4 mr-2 text-red-500" />
                Stop Recording
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 mr-2" />
                Voice to Text
              </>
            )}
          </Button>
        </div>
        <Textarea
          placeholder="Provide detailed information about the issue, including when you first noticed it, how it affects the community, and any other relevant details..."
          value={issueData.description}
          onChange={(e) => handleDescriptionChange(e.target.value)}
          className="min-h-32 resize-none"
        />
        <div className="flex justify-between items-center mt-2">
          <div className="text-sm text-muted-foreground">{descCount}/500 characters</div>
        </div>

        {/* Template Suggestions */}
        <div className="mt-4">
          <p className="text-sm font-medium text-foreground mb-2">Quick Templates:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {templates.map((template, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => setIssueData({ ...issueData, description: template })}
                className="text-left h-auto p-3 text-xs"
              >
                {template.substring(0, 60)}...
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Priority Level */}
      <div>
        <label className="block text-sm font-medium text-foreground mb-4">Priority Level *</label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {priorities.map((priority) => {
            const isSelected = issueData.priority?.level === priority.level

            return (
              <Card
                key={priority.level}
                className={`
                  cursor-pointer transition-all duration-200 hover:shadow-md
                  ${
                    isSelected
                      ? `${priority.borderColor} border-2 ${priority.bgColor}`
                      : "border-border hover:border-border/80"
                  }
                `}
                onClick={() => selectPriority(priority)}
              >
                <CardContent className="p-4 text-center">
                  <div
                    className={`
                    w-4 h-4 rounded-full mx-auto mb-3
                    ${priority.color.replace("text-", "bg-")}
                  `}
                  />
                  <h4 className="font-semibold text-foreground mb-1 text-sm">{priority.label}</h4>
                  <p className="text-xs text-muted-foreground">{priority.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Expected Resolution Time */}
      {issueData.priority && (
        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-medium text-foreground mb-2">Expected Resolution Time</h4>
          <p className="text-sm text-muted-foreground">
            Based on your selected category and priority level, this issue typically takes{" "}
            <span className="font-semibold text-foreground">
              {issueData.priority.value === 4
                ? "24-48 hours"
                : issueData.priority.value === 3
                  ? "3-5 business days"
                  : issueData.priority.value === 2
                    ? "1-2 weeks"
                    : "2-4 weeks"}
            </span>{" "}
            to resolve.
          </p>
        </div>
      )}
    </div>
  )
}
