import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowRight, Mail, Smartphone, Facebook, Twitter, Instagram } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-24 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Newsletter Signup */}
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Stay Connected with Your Community</h2>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Get weekly updates on resolved issues in your area, new features, and civic engagement opportunities.
            </p>

            <Card className="border-border/50">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <Input type="email" placeholder="Enter your email address" className="h-12" />
                  </div>
                  <Button size="lg" className="bg-primary hover:bg-primary/90">
                    <Mail className="w-4 h-4 mr-2" />
                    Subscribe
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground mt-3">
                  Join 25,000+ citizens already subscribed. Unsubscribe anytime.
                </p>
              </CardContent>
            </Card>

            {/* Social Links */}
            <div className="mt-8">
              <p className="text-sm text-muted-foreground mb-4">Follow us on social media:</p>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  <Facebook className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Twitter className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Instagram className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile App CTA */}
          <div className="text-center lg:text-left">
            <div className="inline-block p-8 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl">
              <Smartphone className="w-16 h-16 text-primary mx-auto lg:mx-0 mb-6" />
              <h3 className="text-2xl font-bold text-foreground mb-4">Get the Mobile App</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Report issues on the go with our mobile app. Available for iOS and Android with offline support and push
                notifications.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button variant="outline" className="flex items-center gap-2 bg-transparent">
                  <img src="/apple-logo-minimalist.png" alt="App Store" className="w-6 h-6" />
                  App Store
                </Button>
                <Button variant="outline" className="flex items-center gap-2 bg-transparent">
                  <img src="/google-play-logo.png" alt="Google Play" className="w-6 h-6" />
                  Google Play
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className="text-center mt-16 pt-16 border-t border-border">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Ready to Make a Difference?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-balance">
            Join thousands of citizens who are already transforming their communities through civic engagement.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 px-8 py-4 text-lg">
              Start Reporting Issues
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4 text-lg bg-transparent">
              Explore the Platform
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
