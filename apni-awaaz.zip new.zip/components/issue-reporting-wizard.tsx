"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { CategorySelection } from "@/components/report/category-selection"
import { IssueDetails } from "@/components/report/issue-details"
import { LocationMedia } from "@/components/report/location-media"
import { ReviewSubmit } from "@/components/report/review-submit"
import { SuccessPage } from "@/components/report/success-page"
import { ChevronLeft, ChevronRight } from "lucide-react"

export interface IssueData {
  category: {
    id: string
    name: string
    icon: string
    color: string
  } | null
  title: string
  description: string
  priority: {
    level: string
    value: number
    label: string
    color: string
  } | null
  location: {
    coordinates: [number, number] | null
    address: string
    landmark: string
  }
  media: {
    photos: File[]
    video: File | null
  }
  contact: {
    sms: boolean
    email: boolean
    push: boolean
    inApp: boolean
    phone: string
  }
  privacy: {
    public: boolean
    allowMedia: boolean
    anonymous: boolean
  }
}

export function IssueReportingWizard() {
  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [issueData, setIssueData] = useState<IssueData>({
    category: null,
    title: "",
    description: "",
    priority: null,
    location: {
      coordinates: null,
      address: "",
      landmark: "",
    },
    media: {
      photos: [],
      video: null,
    },
    contact: {
      sms: true,
      email: true,
      push: true,
      inApp: true,
      phone: "",
    },
    privacy: {
      public: true,
      allowMedia: true,
      anonymous: false,
    },
  })

  const steps = [
    { number: 1, title: "Category", description: "Select issue type" },
    { number: 2, title: "Details", description: "Describe the problem" },
    { number: 3, title: "Location", description: "Add location & photos" },
    { number: 4, title: "Review", description: "Review & submit" },
  ]

  const progress = (currentStep / steps.length) * 100

  const nextStep = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSubmit = () => {
    // Here you would typically submit to an API
    console.log("Submitting issue:", issueData)
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return <SuccessPage issueData={issueData} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Report a Civic Issue</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Help improve your community by reporting issues that need attention from local authorities.
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center">
                <div
                  className={`
                  w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold
                  ${
                    currentStep >= step.number ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }
                `}
                >
                  {step.number}
                </div>
                <div className="ml-3 hidden sm:block">
                  <div
                    className={`text-sm font-medium ${
                      currentStep >= step.number ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {step.title}
                  </div>
                  <div className="text-xs text-muted-foreground">{step.description}</div>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`
                    hidden sm:block w-16 h-0.5 ml-4
                    ${currentStep > step.number ? "bg-primary" : "bg-muted"}
                  `}
                  />
                )}
              </div>
            ))}
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Content */}
        <Card className="border-border/50 shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">
              Step {currentStep}: {steps[currentStep - 1].title}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {currentStep === 1 && <CategorySelection issueData={issueData} setIssueData={setIssueData} />}
            {currentStep === 2 && <IssueDetails issueData={issueData} setIssueData={setIssueData} />}
            {currentStep === 3 && <LocationMedia issueData={issueData} setIssueData={setIssueData} />}
            {currentStep === 4 && (
              <ReviewSubmit issueData={issueData} setIssueData={setIssueData} onSubmit={handleSubmit} />
            )}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 1}
            className="flex items-center gap-2 bg-transparent"
          >
            <ChevronLeft className="w-4 h-4" />
            Previous
          </Button>

          {currentStep < steps.length ? (
            <Button
              onClick={nextStep}
              disabled={
                (currentStep === 1 && !issueData.category) ||
                (currentStep === 2 && (!issueData.title || !issueData.priority)) ||
                (currentStep === 3 && !issueData.location.address)
              }
              className="flex items-center gap-2"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} className="bg-primary hover:bg-primary/90">
              Submit Report
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
