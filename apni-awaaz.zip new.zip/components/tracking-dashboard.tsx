"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SearchFilters } from "@/components/track/search-filters"
import { IssueCard } from "@/components/track/issue-card"
import { IssueDetailModal } from "@/components/track/issue-detail-modal"
import { Search, Filter, Grid, List, ScanLine, Mic } from "lucide-react"

// Mock data for demonstration
const mockIssues = [
  {
    id: "IZ2025001234",
    title: "Large pothole on MG Road causing traffic issues",
    category: { name: "Roads & Transport", color: "text-red-500", icon: "Car" },
    priority: { level: "high", label: "High Priority", color: "text-orange-500" },
    status: { current: "in_progress", label: "In Progress", color: "text-yellow-500", progress: 65 },
    location: { address: "MG Road, Connaught Place, New Delhi", landmark: "Near Rajiv Chowk Metro" },
    submittedDate: "2025-01-15T10:30:00Z",
    lastUpdated: "2025-01-20T14:22:00Z",
    department: "Public Works Department",
    assignedOfficer: "Rajesh Kumar",
    images: ["/pothole-on-road-before-repair.jpg"],
    upvotes: 23,
    comments: 8,
    description:
      "There is a large pothole on MG Road near the metro station that has been causing significant traffic delays and vehicle damage. The pothole is approximately 3 feet wide and 1 foot deep.",
  },
  {
    id: "IZ2025001567",
    title: "Broken street light making area unsafe",
    category: { name: "Electricity & Street Lights", color: "text-yellow-500", icon: "Lightbulb" },
    priority: { level: "medium", label: "Medium Priority", color: "text-yellow-500" },
    status: { current: "resolved", label: "Resolved", color: "text-green-500", progress: 100 },
    location: { address: "Sector 15, Gurgaon", landmark: "Near Community Center" },
    submittedDate: "2025-01-10T18:45:00Z",
    lastUpdated: "2025-01-12T09:15:00Z",
    department: "Electricity Board",
    assignedOfficer: "Priya Sharma",
    images: ["/dark-street-with-broken-streetlight.jpg", "/well-lit-street-with-working-streetlight.jpg"],
    upvotes: 15,
    comments: 5,
    description: "The street light has been broken for over a week, making the area unsafe for pedestrians at night.",
  },
  {
    id: "IZ2025001890",
    title: "Irregular garbage collection in residential area",
    category: { name: "Sanitation & Cleanliness", color: "text-green-500", icon: "Trash2" },
    priority: { level: "low", label: "Low Priority", color: "text-green-500" },
    status: { current: "acknowledged", label: "Acknowledged", color: "text-blue-500", progress: 25 },
    location: { address: "Lajpat Nagar, Delhi", landmark: "Block A, Near Park" },
    submittedDate: "2025-01-08T12:20:00Z",
    lastUpdated: "2025-01-09T08:30:00Z",
    department: "Municipal Corporation",
    assignedOfficer: "Amit Singh",
    images: ["/overflowing-garbage-bins-on-street.jpg"],
    upvotes: 31,
    comments: 12,
    description:
      "Garbage collection has been irregular in our area for the past month, leading to overflowing bins and hygiene issues.",
  },
]

export function TrackingDashboard() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedIssue, setSelectedIssue] = useState<(typeof mockIssues)[0] | null>(null)
  const [isVoiceSearch, setIsVoiceSearch] = useState(false)

  const filteredIssues = mockIssues.filter(
    (issue) =>
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.address.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const toggleVoiceSearch = () => {
    setIsVoiceSearch(!isVoiceSearch)
    // Here you would implement voice search functionality
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/10 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Track Your Issues</h1>
          <p className="text-lg text-muted-foreground max-w-3xl">
            Monitor the progress of your reported issues and stay updated with real-time notifications from government
            departments.
          </p>
        </div>

        {/* Search and Filter Header */}
        <Card className="mb-8 border-border/50">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search Bar */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  placeholder="Search by issue ID, location, or keywords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-20 h-12 text-lg"
                />
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleVoiceSearch}
                    className={isVoiceSearch ? "bg-red-50 text-red-500" : ""}
                  >
                    <Mic className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <ScanLine className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2"
                >
                  <Filter className="w-4 h-4" />
                  Filters
                </Button>
                <div className="flex border border-border rounded-lg">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Filters Panel */}
            {showFilters && (
              <div className="mt-6 pt-6 border-t border-border">
                <SearchFilters />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Issues</p>
                  <p className="text-2xl font-bold text-foreground">12</p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <div className="w-6 h-6 bg-primary rounded-full" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold text-foreground">5</p>
                </div>
                <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
                  <div className="w-6 h-6 bg-yellow-500 rounded-full" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Resolved</p>
                  <p className="text-2xl font-bold text-foreground">6</p>
                </div>
                <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <div className="w-6 h-6 bg-green-500 rounded-full" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Resolution</p>
                  <p className="text-2xl font-bold text-foreground">4.2d</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center">
                  <div className="w-6 h-6 bg-blue-500 rounded-full" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Issues List */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-foreground">My Issues ({filteredIssues.length})</h2>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Sort by:</span>
              <select className="bg-background border border-border rounded px-2 py-1">
                <option>Most Recent</option>
                <option>Priority</option>
                <option>Status</option>
                <option>Location</option>
              </select>
            </div>
          </div>

          {filteredIssues.length === 0 ? (
            <Card className="border-border/50">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">No issues found</h3>
                <p className="text-muted-foreground mb-6">
                  {searchQuery ? "Try adjusting your search terms or filters" : "You haven't reported any issues yet"}
                </p>
                <Button>Report Your First Issue</Button>
              </CardContent>
            </Card>
          ) : (
            <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
              {filteredIssues.map((issue) => (
                <IssueCard key={issue.id} issue={issue} viewMode={viewMode} onClick={() => setSelectedIssue(issue)} />
              ))}
            </div>
          )}
        </div>

        {/* Issue Detail Modal */}
        {selectedIssue && (
          <IssueDetailModal issue={selectedIssue} isOpen={!!selectedIssue} onClose={() => setSelectedIssue(null)} />
        )}
      </div>
    </div>
  )
}
