"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import {
  MapPin,
  User,
  Phone,
  Mail,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Download,
  Camera,
  Star,
  CheckCircle,
  AlertCircle,
  X,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"

interface Issue {
  id: string
  title: string
  category: { name: string; color: string; icon: string }
  priority: { level: string; label: string; color: string }
  status: { current: string; label: string; color: string; progress: number }
  location: { address: string; landmark?: string }
  submittedDate: string
  lastUpdated: string
  department: string
  assignedOfficer: string
  images: string[]
  upvotes: number
  comments: number
  description: string
}

interface IssueDetailModalProps {
  issue: Issue
  isOpen: boolean
  onClose: () => void
}

export function IssueDetailModal({ issue, isOpen, onClose }: IssueDetailModalProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [newComment, setNewComment] = useState("")
  const [hasUpvoted, setHasUpvoted] = useState(false)

  const timeline = [
    {
      status: "submitted",
      timestamp: issue.submittedDate,
      actor: "citizen",
      message: "Issue reported by citizen",
      icon: CheckCircle,
      color: "text-blue-500",
    },
    {
      status: "acknowledged",
      timestamp: "2025-01-15T11:15:00Z",
      actor: "system",
      message: "Automatically assigned to PWD",
      icon: AlertCircle,
      color: "text-blue-600",
    },
    {
      status: "in_progress",
      timestamp: "2025-01-16T09:30:00Z",
      actor: "official",
      message: "Field team dispatched for assessment",
      icon: User,
      color: "text-yellow-500",
    },
  ]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % issue.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + issue.images.length) % issue.images.length)
  }

  const handleUpvote = () => {
    setHasUpvoted(!hasUpvoted)
  }

  const handleComment = () => {
    if (newComment.trim()) {
      // Here you would submit the comment
      setNewComment("")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold">Issue Details</DialogTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline">#{issue.id}</Badge>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Media Gallery */}
          {issue.images.length > 0 && (
            <div className="relative">
              <div className="aspect-video bg-muted rounded-lg overflow-hidden">
                <img
                  src={issue.images[currentImageIndex] || "/placeholder.svg"}
                  alt={`Issue photo ${currentImageIndex + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>

              {issue.images.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                    onClick={prevImage}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                    onClick={nextImage}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">
                    {currentImageIndex + 1} / {issue.images.length}
                  </div>
                </>
              )}

              <div className="flex gap-2 mt-3">
                {issue.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${
                      index === currentImageIndex ? "border-primary" : "border-transparent"
                    }`}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`Thumbnail ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Issue Information */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Title and Description */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="secondary">{issue.category.name}</Badge>
                  <div className={`w-3 h-3 rounded-full ${issue.priority.color.replace("text-", "bg-")}`} />
                  <span className="text-sm text-muted-foreground">{issue.priority.label}</span>
                </div>
                <h2 className="text-2xl font-bold text-foreground mb-4">{issue.title}</h2>
                <p className="text-muted-foreground leading-relaxed">{issue.description}</p>
              </div>

              {/* Status Timeline */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-4">Status Timeline</h3>
                  <div className="space-y-4">
                    {timeline.map((item, index) => {
                      const Icon = item.icon
                      return (
                        <div key={index} className="flex items-start gap-3">
                          <div
                            className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0`}
                          >
                            <Icon className={`w-4 h-4 ${item.color}`} />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-foreground">{item.message}</p>
                              <span className="text-xs text-muted-foreground">{formatDate(item.timestamp)}</span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Community Interaction */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-foreground mb-4">Community Discussion</h3>

                  {/* Voting */}
                  <div className="flex items-center gap-4 mb-6">
                    <Button
                      variant={hasUpvoted ? "default" : "outline"}
                      size="sm"
                      onClick={handleUpvote}
                      className="flex items-center gap-2"
                    >
                      <ThumbsUp className="w-4 h-4" />
                      {hasUpvoted ? issue.upvotes + 1 : issue.upvotes}
                    </Button>
                    <Button variant="outline" size="sm">
                      <ThumbsDown className="w-4 h-4" />
                    </Button>
                    <span className="text-sm text-muted-foreground">{issue.comments} people are discussing this</span>
                  </div>

                  {/* Comment Form */}
                  <div className="space-y-3">
                    <Textarea
                      placeholder="Add your comment or additional information..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="min-h-20"
                    />
                    <div className="flex justify-between items-center">
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Camera className="w-4 h-4 mr-2" />
                          Add Photo
                        </Button>
                      </div>
                      <Button onClick={handleComment} disabled={!newComment.trim()}>
                        Post Comment
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Status Progress */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-foreground mb-3">Current Status</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className={`font-medium ${issue.status.color}`}>{issue.status.label}</span>
                      <span className="text-sm text-muted-foreground">{issue.status.progress}%</span>
                    </div>
                    <Progress value={issue.status.progress} className="h-3" />
                    <p className="text-sm text-muted-foreground">Last updated: {formatDate(issue.lastUpdated)}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Location */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-foreground mb-3">Location</h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-muted-foreground">{issue.location.address}</span>
                    </div>
                    {issue.location.landmark && (
                      <div className="flex items-start gap-2">
                        <div className="w-4 h-4 mt-0.5" />
                        <span className="text-sm text-muted-foreground">Near {issue.location.landmark}</span>
                      </div>
                    )}
                  </div>
                  <div className="mt-4 h-32 bg-muted rounded-lg flex items-center justify-center">
                    <span className="text-sm text-muted-foreground">Interactive Map</span>
                  </div>
                </CardContent>
              </Card>

              {/* Government Response */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-foreground mb-3">Assigned Department</h3>
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium text-foreground">{issue.department}</p>
                      <p className="text-sm text-muted-foreground">Responsible Department</p>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{issue.assignedOfficer}</p>
                      <p className="text-sm text-muted-foreground">Assigned Officer</p>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <Phone className="w-4 h-4 mr-2" />
                        Call
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-foreground mb-3">Actions</h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Share2 className="w-4 h-4 mr-2" />
                      Share Issue
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Download className="w-4 h-4 mr-2" />
                      Download Report
                    </Button>
                    <Button variant="outline" className="w-full justify-start bg-transparent">
                      <Star className="w-4 h-4 mr-2" />
                      Subscribe to Updates
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
