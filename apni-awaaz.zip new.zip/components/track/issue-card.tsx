"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MapPin, Calendar, MessageSquare, ThumbsUp, Share2, MoreHorizontal, Clock, User } from "lucide-react"

interface Issue {
  id: string
  title: string
  category: { name: string; color: string; icon: string }
  priority: { level: string; label: string; color: string }
  status: { current: string; label: string; color: string; progress: number }
  location: { address: string; landmark?: string }
  submittedDate: string
  lastUpdated: string
  department: string
  assignedOfficer: string
  images: string[]
  upvotes: number
  comments: number
  description: string
}

interface IssueCardProps {
  issue: Issue
  viewMode: "grid" | "list"
  onClick: () => void
}

export function IssueCard({ issue, viewMode, onClick }: IssueCardProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-IN", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getDaysAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays === 1 ? "1 day ago" : `${diffDays} days ago`
  }

  if (viewMode === "list") {
    return (
      <Card className="border-border/50 hover:shadow-md transition-all duration-200 cursor-pointer" onClick={onClick}>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            {/* Image */}
            <div className="w-20 h-20 bg-muted rounded-lg overflow-hidden flex-shrink-0">
              {issue.images[0] ? (
                <img src={issue.images[0] || "/placeholder.svg"} alt="Issue" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <MapPin className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant="outline" className="text-xs">
                    #{issue.id}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {issue.category.name}
                  </Badge>
                  <div className={`w-2 h-2 rounded-full ${issue.priority.color.replace("text-", "bg-")}`} />
                </div>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>

              <h3 className="font-semibold text-foreground text-lg mb-2 line-clamp-1">{issue.title}</h3>

              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span className="truncate max-w-48">{issue.location.address}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{getDaysAgo(issue.submittedDate)}</span>
                </div>
              </div>

              {/* Status Progress */}
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-medium ${issue.status.color}`}>{issue.status.label}</span>
                  <span className="text-xs text-muted-foreground">{issue.status.progress}%</span>
                </div>
                <Progress value={issue.status.progress} className="h-2" />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="w-4 h-4" />
                    <span>{issue.upvotes}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    <span>{issue.comments}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card
      className="border-border/50 hover:shadow-lg transition-all duration-300 cursor-pointer group"
      onClick={onClick}
    >
      <CardContent className="p-0">
        {/* Image */}
        <div className="relative h-48 bg-muted overflow-hidden">
          {issue.images[0] ? (
            <img
              src={issue.images[0] || "/placeholder.svg"}
              alt="Issue"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <MapPin className="w-12 h-12 text-muted-foreground" />
            </div>
          )}

          {/* Overlays */}
          <div className="absolute top-3 left-3">
            <Badge variant="secondary" className="text-xs font-medium">
              #{issue.id}
            </Badge>
          </div>
          <div className="absolute top-3 right-3">
            <div className={`w-3 h-3 rounded-full ${issue.priority.color.replace("text-", "bg-")}`} />
          </div>
          {issue.images.length > 1 && (
            <div className="absolute bottom-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-xs">
              +{issue.images.length - 1}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <Badge variant="outline" className="text-xs">
              {issue.category.name}
            </Badge>
            <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-foreground text-lg mb-3 line-clamp-2 leading-tight">{issue.title}</h3>

          {/* Location */}
          <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{issue.location.address}</span>
          </div>

          {/* Status Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className={`text-sm font-medium ${issue.status.color}`}>{issue.status.label}</span>
              <span className="text-xs text-muted-foreground">{issue.status.progress}%</span>
            </div>
            <Progress value={issue.status.progress} className="h-2" />
          </div>

          {/* Meta Info */}
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{getDaysAgo(issue.submittedDate)}</span>
            </div>
            <div className="flex items-center gap-1">
              <User className="w-3 h-3" />
              <span>{issue.assignedOfficer}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <ThumbsUp className="w-4 h-4" />
                <span>{issue.upvotes}</span>
              </div>
              <div className="flex items-center gap-1">
                <MessageSquare className="w-4 h-4" />
                <span>{issue.comments}</span>
              </div>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="sm">
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
