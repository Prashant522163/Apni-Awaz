"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, MapPin, Filter } from "lucide-react"

export function SearchFilters() {
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedPriorities, setSelectedPriorities] = useState<string[]>([])

  const statuses = [
    { id: "submitted", label: "Submitted", color: "bg-blue-500" },
    { id: "acknowledged", label: "Acknowledged", color: "bg-blue-600" },
    { id: "in_progress", label: "In Progress", color: "bg-yellow-500" },
    { id: "under_review", label: "Under Review", color: "bg-purple-500" },
    { id: "resolved", label: "Resolved", color: "bg-green-500" },
    { id: "rejected", label: "Rejected", color: "bg-red-500" },
  ]

  const categories = [
    { id: "roads", label: "Roads & Transport", icon: "🚗" },
    { id: "sanitation", label: "Sanitation", icon: "🗑️" },
    { id: "water", label: "Water & Drainage", icon: "💧" },
    { id: "electricity", label: "Electricity", icon: "💡" },
    { id: "safety", label: "Public Safety", icon: "🛡️" },
    { id: "parks", label: "Parks & Spaces", icon: "🌳" },
  ]

  const priorities = [
    { id: "low", label: "Low", color: "bg-green-500" },
    { id: "medium", label: "Medium", color: "bg-yellow-500" },
    { id: "high", label: "High", color: "bg-orange-500" },
    { id: "urgent", label: "Urgent", color: "bg-red-500" },
  ]

  const toggleSelection = (value: string, selected: string[], setSelected: (values: string[]) => void) => {
    if (selected.includes(value)) {
      setSelected(selected.filter((item) => item !== value))
    } else {
      setSelected([...selected, value])
    }
  }

  const clearAllFilters = () => {
    setSelectedStatuses([])
    setSelectedCategories([])
    setSelectedPriorities([])
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Filter className="w-5 h-5" />
          Filters
        </h3>
        <Button variant="ghost" size="sm" onClick={clearAllFilters}>
          Clear All
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Status Filter */}
        <Card className="border-border/50">
          <CardContent className="p-4">
            <h4 className="font-medium text-foreground mb-3">Status</h4>
            <div className="space-y-2">
              {statuses.map((status) => (
                <div key={status.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={status.id}
                    checked={selectedStatuses.includes(status.id)}
                    onCheckedChange={() => toggleSelection(status.id, selectedStatuses, setSelectedStatuses)}
                  />
                  <label htmlFor={status.id} className="flex items-center gap-2 text-sm cursor-pointer">
                    <div className={`w-2 h-2 rounded-full ${status.color}`} />
                    {status.label}
                  </label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Category Filter */}
        <Card className="border-border/50">
          <CardContent className="p-4">
            <h4 className="font-medium text-foreground mb-3">Category</h4>
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={category.id}
                    checked={selectedCategories.includes(category.id)}
                    onCheckedChange={() => toggleSelection(category.id, selectedCategories, setSelectedCategories)}
                  />
                  <label htmlFor={category.id} className="flex items-center gap-2 text-sm cursor-pointer">
                    <span>{category.icon}</span>
                    {category.label}
                  </label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Priority Filter */}
        <Card className="border-border/50">
          <CardContent className="p-4">
            <h4 className="font-medium text-foreground mb-3">Priority</h4>
            <div className="space-y-2">
              {priorities.map((priority) => (
                <div key={priority.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={priority.id}
                    checked={selectedPriorities.includes(priority.id)}
                    onCheckedChange={() => toggleSelection(priority.id, selectedPriorities, setSelectedPriorities)}
                  />
                  <label htmlFor={priority.id} className="flex items-center gap-2 text-sm cursor-pointer">
                    <div className={`w-2 h-2 rounded-full ${priority.color}`} />
                    {priority.label}
                  </label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Date & Location Filter */}
        <Card className="border-border/50">
          <CardContent className="p-4">
            <h4 className="font-medium text-foreground mb-3">Date & Location</h4>
            <div className="space-y-3">
              <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                <Calendar className="w-4 h-4 mr-2" />
                Date Range
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                <MapPin className="w-4 h-4 mr-2" />
                Location
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
