import { Navigation } from "@/components/navigation"
import { TrackingDashboard } from "@/components/tracking-dashboard"

export default function TrackPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        <TrackingDashboard />
      </div>
    </main>
  )
}
