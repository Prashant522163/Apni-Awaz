import { Navigation } from "@/components/navigation"
import { IssueReportingWizard } from "@/components/issue-reporting-wizard"

export default function ReportPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        <IssueReportingWizard />
      </div>
    </main>
  )
}
