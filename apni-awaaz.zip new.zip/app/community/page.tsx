import { Navigation } from "@/components/navigation"
import { CommunityForum } from "@/components/community-forum"

export default function CommunityPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <div className="pt-16">
        <CommunityForum />
      </div>
    </main>
  )
}
